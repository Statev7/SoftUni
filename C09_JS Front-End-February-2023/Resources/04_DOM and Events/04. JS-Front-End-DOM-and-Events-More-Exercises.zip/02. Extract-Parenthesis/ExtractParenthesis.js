function extract(content) {

}